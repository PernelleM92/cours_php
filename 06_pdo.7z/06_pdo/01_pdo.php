<?php require_once '../inc/functions.php'; ?> 
<!doctype html>
<html lang="fr">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <title>Cours PHP 7 - PDO</title>
    <!-- mes styles -->
    <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
  <?php require '../inc/navigation.inc.php'; ?>
    <!-- navigation en include  -->
    <div class="jumbotron container mt-4">
        <h1 class="display-4">COURS PHP 7 - PDO ( PHP DATA OBJECT)</h1>
        <p class="lead">La variable "$pdo" est un objet qui représente la connexion à un BDD</p>
        <hr class="my-4">
    </div>
    <!-- =================================== -->
    <!-- Contenu principal -->
    <!-- =================================== -->
    <main class="container bg-white mb-5 pb-4">
        <div class="row">
            <div class="col-sm-12">
            <h2>1-Connexion à la BDD</h2>
            <p><abbr title="PHP data object">PDO</abbr> est l'accronyme de PHP Data Object</p>
            <?php 
            $pdoENT = new PDO('mysql:host=localhost;dbname=entreprise',// On a en premier lieu le driver mysql (IBM, ORACLE, ODBC...) le nom du serveur, le nom de la BDD. 
            'root',//L'utilisateur pour le BDD
            '',// si vous ête sur mac il y a un mot de passe = 'root'
            array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, // Cette ligne sert à afficher les erreurs sur le navigateurs 
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',// Cette ligne sert a définir le charset des échanges avec la BDD
            ));

            //Gabarit pour la soutenance
            //Connextion PISOLA
            // $host='localhost';
            // $database='entreprise';
            // $user='root';
            // $psw='';

            // $pdoENT = new PDO('mysql:host='.$host.';dbname='.$database,$user,$psw);
            // $pdoENT ->exec("SET NAMES utf8");

            jevardump($pdoENT); // L'objet est vide car il n'y a pas de propriétés
            jevardump( get_class_methods($pdoENT));// permet d'afficher la liste des méthodes présentes dans la l'objet PDO
                
            ?> 
                
                
            </div>
            <!-- fin col -->
            <div class="col-sm-12">
            <h2>2-Faire des requêtes avec exec()</h2>
            <p>La méthode exec() est utilisée pour faire des requêtes qui ne retourne pas de résultats: INSERT, UPDATE, DELETE</p>
            <?php 
            //On va isérer un employé dans la BDD
            //Requêye sql d'insertion de la bdd et dans la table employés //INSERT INTO employes (prenom, nom, sexe, service, date_embauche, salaire) VALUES ('Jean', 'Bon', 'm', 'informatique', '2021-03-18', 2000)

            // $requête = $pdoENT->exec(  "INSERT INTO employes (prenom, nom, sexe, service, date_embauche, salaire) VALUES ('Jean', 'Bon', 'm', 'informatique', '2021-03-18', 2000)" )

            $requete =  $pdoENT->exec( "DELETE FROM employes WHERE prenom = 'Jean' AND nom='Bon'" );
             
            ?> 

            
            </div> <!--fin de col-->
       </div> <!-- fin row -->


    </main>
    <!-- footer en include -->
    <?php include '../inc/footer.inc.php'; ?>
    <!-- Optional JavaScript; choose one of the two! -->
    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
